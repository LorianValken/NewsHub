<?php 
    include('sidebar.php');
    
    // --- HANDLE DELETE LOGIC ---
    if(isset($_POST['btn_remove_news'])){
        $remove_id = (int)$_POST['remove_id']; 

        $sql_delete = "DELETE FROM tbl_news WHERE id = '$remove_id'";
        $rs_delete  = connection_db()->query($sql_delete);

        if($rs_delete){
            echo "<script>
                // alert('News deleted successfully!');
                window.location.href = 'news-view-post.php';
            </script>";
        } else {
            echo "<script>alert('Error deleting news.');</script>";
        }
    }
?>

<div class="col-12 col-lg-10 bg-light transition-all"> 
    
    <div class="content-right p-3 p-md-4"> 
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
            <div>
                <h3 class="fw-bold text-dark m-0">News Management</h3>
                <p class="text-muted small m-0">Overview of all published articles</p>
            </div>
            
            <a href="news-add-post.php" class="btn btn-primary rounded-pill px-4 shadow-sm">
                <i class="bi bi-plus-lg"></i> Add New Post
            </a> 
        </div>

        <style>
            .card { border: none; border-radius: 12px; overflow: hidden; }
            
            /* Table Header Styling */
            .table thead th {
                font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px;
                color: #6c757d; font-weight: 700; background-color: #f8f9fa;
                border-bottom: 2px solid #e9ecef; padding: 1rem;
                white-space: nowrap; 
            }
            .table tbody td {
                padding: 1rem 1rem; vertical-align: middle; color: #495057;
                font-size: 0.95rem; border-bottom: 1px solid #f0f0f0;
            }
            .table-hover tbody tr:hover { background-color: #fcfcfc; }
            
            /* Scrollbar Styling */
            .table-responsive::-webkit-scrollbar { height: 6px; }
            .table-responsive::-webkit-scrollbar-track { background: #f1f1f1; }
            .table-responsive::-webkit-scrollbar-thumb { background: #ccc; border-radius: 4px; }
            .table-responsive::-webkit-scrollbar-thumb:hover { background: #bbb; }

            /* Pagination Styles */
            .page-link { border-radius: 50% !important; margin: 0 4px; border: none; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; color: #555; font-weight: 500; }
            .page-item.active .page-link { background-color: #0d6efd; color: white; box-shadow: 0 3px 6px rgba(13, 110, 253, 0.3); }

            @media (max-width: 768px) {
                .table-responsive {
                    border: none;
                }
                .table thead {
                    display: none;
                }
                .table tbody, .table tr, .table td {
                    display: block;
                    width: 100%;
                }
                .table tr {
                    margin-bottom: 1rem;
                    border: 1px solid #eee;
                    border-radius: 10px;
                    padding: 10px;
                }
                .table td {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    border: none;
                    padding: 0.5rem 0;
                }
                .table td::before {
                    content: attr(data-label);
                    font-weight: 600;
                    margin-right: 10px;
                    color: #333;
                }
                .table td:last-child {
                    justify-content: flex-start;
                }
            }
        </style>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>News Type</th>
                                <th>Category</th>
                                <th>Thumbnail</th>
                                <th>Views</th>
                                <th>Created By</th>
                                <th>Publish Date</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $limit  = 10;
                                $page   = isset($_GET['page']) ? $_GET['page'] : 1;
                                $offset = ($page - 1) * $limit;
                                
                                $total_news = get_total_records('tbl_news');
                                if ($total_news > 0) {
                                    view_list_news($offset, $limit);
                                } else {
                                    echo '<tr><td colspan="8" class="text-center py-5 text-muted">Data Not Found</td></tr>';
                                }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center p-3 border-top bg-white">
                    <div class="text-muted small mb-3 mb-md-0">
                        Showing page <b><?php echo $page; ?></b>
                    </div>
                    <nav aria-label="Page navigation">
                        <ul class="pagination mb-0">
                            <?php
                                $total_page = ceil($total_news / $limit);

                                if ($page > 1) echo '<li class="page-item"><a class="page-link" href="?page='.($page - 1).'"><i class="bi bi-chevron-left"></i></a></li>';
                                
                                for($i=1; $i<=$total_page; $i++){
                                    $active = ($i == $page) ? 'active' : '';
                                    echo '<li class="page-item '.$active.'"><a class="page-link" href="?page='.$i.'">'.$i.'</a></li>';
                                }

                                if ($page < $total_page) echo '<li class="page-item"><a class="page-link" href="?page='.($page + 1).'"><i class="bi bi-chevron-right"></i></a></li>';
                            ?>
                        </ul>
                    </nav>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-body text-center p-5">
                <div class="mb-3 text-danger">
                    <i class="bi bi-exclamation-circle" style="font-size: 3rem;"></i>
                </div>
                <h4 class="mb-2">Delete this post?</h4>
                <p class="text-muted mb-4">Are you sure you want to remove this news item?</p>
                <form method="post">
                    <input type="hidden" id="remove_id" name="remove_id"> 
                    <div class="d-flex justify-content-center gap-2">
                        <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>  
                        <button type="submit" class="btn btn-danger px-4" name="btn_remove_news">Yes, Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '.btn-remove', function() {
        var id = $(this).attr('remove-id');
        $('#remove_id').val(id);
    });
</script>