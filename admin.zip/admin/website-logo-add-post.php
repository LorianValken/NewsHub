<?php
include('sidebar.php');
add_website_logo();
?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    /* Scope styles to content-right */
    .content-right {
        font-family: 'Inter', sans-serif;
        background-color: #f8fafc;
        min-height: 100vh;
        padding: 15px;
        transition: all 0.3s ease;
    }

    /* Card Styling */
    .admin-card {
        background: #ffffff;
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        border: 1px solid #e2e8f0;
        padding: 1.5rem;
        margin-top: 1rem;
    }

    /* Form Labels & Inputs */
    .form-label-custom {
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 0.5rem;
        display: block;
        font-size: 0.95rem;
    }

    .form-select-custom {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        font-size: 1rem;
        width: 100%;
        background-color: #fff;
        height: 48px;
    }

    .form-select-custom:focus {
        border-color: #4361ee;
        outline: none;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
    }

    /* Modern Upload Area */
    .upload-container {
        width: 100%;
    }

    .upload-area {
        position: relative;
        width: 100%;
        height: 200px; /* Mobile height */
        border: 2px dashed #e2e8f0;
        border-radius: 12px;
        background-color: #f8fafc;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .upload-area:hover {
        border-color: #4361ee;
        background-color: #eff6ff;
    }

    .upload-area input[type="file"] {
        position: absolute;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        z-index: 10;
    }

    .upload-content {
        text-align: center;
        pointer-events: none;
        color: #64748b;
        padding: 10px;
        transition: opacity 0.3s;
    }

    .upload-content i {
        font-size: 2rem;
        color: #4361ee;
        margin-bottom: 0.5rem;
    }

    .preview-image {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        z-index: 5;
        border-radius: 10px;
        display: none;
        background-color: #fff;
    }

    /* Buttons */
    .btn-submit {
        background-color: #4361ee;
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        border: none;
        font-weight: 600;
        transition: background 0.2s;
        width: 100%; /* Full width on mobile */
    }
    
    .btn-submit:hover {
        background-color: #3a56d4;
        color: white;
    }

    .btn-back {
        background-color: #fff;
        border: 1px solid #e2e8f0;
        color: #64748b;
        padding: 8px 16px; /* Compact padding */
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.2s;
    }

    .btn-back:hover {
        background-color: #f1f5f9;
        color: #1e293b;
        border-color: #cbd5e1;
    }

    .helper-text {
        font-size: 0.8rem;
        color: #94a3b8;
        margin-bottom: 8px;
        display: block;
    }

    /* Desktop Overrides */
    @media (min-width: 768px) {
        .content-right { padding: 30px; }
        .admin-card { padding: 2rem; }
        .upload-area { height: 280px; }
        .btn-submit { width: auto; px: 40px; }
    }
</style>

<div class="col-12 col-lg-10">
    <div class="content-right">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="m-0" style="font-weight: 700; color: #1e293b;">Add Website Logo</h3>
                <p class="m-0 text-muted small">Upload a new logo for header or footer</p>
            </div>
            
            <a href="website-logo-view-post.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>

        <div class="admin-card">
            <form method="post" enctype="multipart/form-data">
                
                <div class="row">
                    <div class="col-12 mb-4">
                        <label class="form-label-custom">Logo Position</label>
                        <select class="form-select-custom" name="type">
                            <option value="header">Header Logo</option>
                            <option value="footer">Footer Logo</option>
                        </select>
                    </div>

                    <div class="col-12 mb-4">
                        <label class="form-label-custom">Upload Image</label>
                        <span class="helper-text">Recommended size: 730 x 415 Pixels (PNG/JPG).</span>
                        
                        <div class="upload-container">
                            <div class="upload-area" id="dropZone">
                                <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
                                
                                <div class="upload-content" id="uploadContent">
                                    <i class="bi bi-cloud-arrow-up upload-icon"></i>
                                    <p style="margin:0; font-weight: 500; color: #1e293b;">Click to upload</p>
                                    <p style="margin:0; font-size: 0.85rem; color: #94a3b8;">or drag and drop here</p>
                                </div>

                                <div class="preview-image" id="filePreview"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-2">
                    <button type="submit" class="btn-submit" name="add_logo">
                        <i class="fas fa-save me-2"></i> Submit Logo
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>

</div>
</div>
</main>
</body>
</html>

<script>
    const input = document.getElementById('thumbnail');
    const preview = document.getElementById('filePreview');
    const content = document.getElementById('uploadContent');
    const dropZone = document.getElementById('dropZone');

    input.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.style.backgroundImage = `url('${e.target.result}')`;
                preview.style.display = 'block';
                content.style.opacity = '0'; // Hide text
                dropZone.style.borderColor = '#10b981'; // Green border success
                dropZone.style.backgroundColor = '#fff';
            }
            reader.readAsDataURL(file);
        } else {
            // Reset if cancelled
            preview.style.backgroundImage = '';
            preview.style.display = 'none';
            content.style.opacity = '1';
            dropZone.style.borderColor = '#e2e8f0';
            dropZone.style.backgroundColor = '#f8fafc';
        }
    });

    // Optional: Visual feedback for Drag and Drop
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.style.borderColor = '#4361ee';
            dropZone.style.backgroundColor = '#eff6ff';
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.style.borderColor = '#e2e8f0';
            dropZone.style.backgroundColor = '#f8fafc';
        }, false);
    });
</script>