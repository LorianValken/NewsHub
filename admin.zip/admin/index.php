<?php include('sidebar.php'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --success-gradient: linear-gradient(135deg, #2af598 0%, #009efd 100%);
        --info-gradient: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
        --card-shadow: 0 10px 20px rgba(0,0,0,0.05);
        --hover-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }

    .dashboard-card { background: #fff; border: none; border-radius: 20px; padding: 25px; position: relative; overflow: hidden; box-shadow: var(--card-shadow); transition: all 0.3s ease; height: 100%; display: flex; flex-direction: column; justify-content: space-between; }
    .dashboard-card:hover { transform: translateY(-5px); box-shadow: var(--hover-shadow); }
    .card-icon { position: absolute; top: 20px; right: 20px; width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; }
    .card-title { color: #6c757d; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px; }
    .card-value { font-size: 2.5rem; font-weight: 700; color: #2d3436; margin: 0; }
    
    .content-container { background: #fff; border-radius: 20px; box-shadow: var(--card-shadow); padding: 25px; height: 100%; border: 1px solid rgba(0,0,0,0.02); }
    .clickable-row { cursor: pointer; transition: background 0.2s; }
    .clickable-row:hover { background-color: #f8f9fa; }

    #fullFeedbackContainer {
        display: none; 
        max-height: 400px; 
        overflow-y: auto;  
        margin-top: 15px;
        border-top: 1px solid #eee;
        padding-top: 15px;
    }
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold m-0">Dashboard Overview</h3>
            <p class="text-muted m-0">Welcome back, Admin</p>
        </div>
        <div class="text-muted"><?php echo date('F d, Y'); ?></div>
    </div>

    <div class="row g-4">
        <div class="col-12 col-md-4">
            <div class="dashboard-card">
                <?php
                    $total_news = get_total_records('tbl_news');
                ?>
                <div><div class="card-title">Total News</div><h2 class="card-value"><?php echo $total_news; ?></h2></div>
                <div class="card-icon" style="background: var(--primary-gradient); box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);"><i class="bi bi-newspaper"></i></div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="dashboard-card">
                <?php
                    $total_feedback = get_total_records('tbl_feedback');
                ?>
                <div><div class="card-title">Total Feedbacks</div><h2 class="card-value"><?php echo $total_feedback; ?></h2></div>
                <div class="card-icon" style="background: var(--success-gradient); box-shadow: 0 4px 15px rgba(42, 245, 152, 0.4);"><i class="bi bi-chat-dots"></i></div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="dashboard-card">
                <?php
                    $total_users = get_total_records('tbl_user');
                ?>
                <div><div class="card-title">Users</div><h2 class="card-value"><?php echo $total_users; ?></h2></div>
                <div class="card-icon" style="background: var(--info-gradient); box-shadow: 0 4px 15px rgba(161, 140, 209, 0.4);"><i class="bi bi-people"></i></div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-2">
        <div class="col-12 col-lg-6">
            <div class="content-container">
                <h4 class="mb-3">News Distribution</h4>
                <div style="height: 300px;"><canvas id="dashboardChart"></canvas></div>
            </div>
        </div>

        <div class="col-12 col-lg-6">
            <div class="content-container">
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <h4 class="m-0">Recent Feedback</h4>
                    <div class="justify-content-end w-100">
                        <button type="button" id="toggleFeedbackBtn" class="btn btn-sm btn-outline-primary rounded-pill" onclick="toggleAllFeedback()">
                            View All
                        </button>
                    </div>
                </div>
                
                <div id="recentFeedbackList" class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light"><tr><th>User</th><th>Message</th><th>Date</th></tr></thead>
                        <tbody>
                            <?php
                            $sql_fb = "SELECT * FROM `tbl_feedback` ORDER BY id DESC LIMIT 5";
                            $rs_fb = connection_db()->query($sql_fb);
                            while ($row_fb = mysqli_fetch_assoc($rs_fb)) {
                            ?>
                            <tr class="clickable-row" 
                                onclick="openFeedbackModalFromAjax('<?php echo htmlspecialchars($row_fb['name']); ?>', '<?php echo htmlspecialchars($row_fb['email']); ?>', '<?php echo date('M d, Y', strtotime($row_fb['created_at'])); ?>', '<?php echo htmlspecialchars(addslashes($row_fb['message'])); ?>')">
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($row_fb['name']); ?></div>
                                    <div class="small text-muted"><?php echo htmlspecialchars($row_fb['email']); ?></div>
                                </td>
                                <td>
                                    <div style="max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                        <?php echo htmlspecialchars($row_fb['message']); ?>
                                    </div>
                                </td>
                                <td class="small text-muted"><?php echo date('M d', strtotime($row_fb['created_at'])); ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <div id="fullFeedbackContainer">
                    <div id="ajaxFeedbackContent"></div>
                </div>

            </div>
        </div>
    </div>

<div class="modal fade" id="feedbackModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <h5 id="modalName" class="fw-bold"></h5>
        <p id="modalEmail" class="text-muted small"></p>
        <div id="modalDate" class="text-muted small mb-3"></div>
        <hr>
        <p id="modalMessage" class="mt-3"></p>
      </div>
    </div>
  </div>
</div>

<?php
$sql_c = "SELECT news_type, COUNT(id) as c FROM tbl_news GROUP BY news_type";
$rs_c = connection_db()->query($sql_c);
$labels=[]; $data=[];
while($r=mysqli_fetch_assoc($rs_c)){ $labels[]=ucfirst($r['news_type']); $data[]=$r['c']; }
?>

<script>
    // Chart
    new Chart(document.getElementById('dashboardChart'), {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{ data: <?php echo json_encode($data); ?>, backgroundColor: ['#667eea','#764ba2','#2af598','#009efd','#fbc2eb'] }]
        },
        options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { position: 'bottom' } } }
    });

    function toggleAllFeedback() {
        const recentList = document.getElementById('recentFeedbackList');
        const fullList = document.getElementById('fullFeedbackContainer');
        const btn = document.getElementById('toggleFeedbackBtn');

        if (fullList.style.display === 'none' || fullList.style.display === '') {
            recentList.style.display = 'none';
            fullList.style.display = 'block';
            btn.innerText = 'Show Less'; 
            btn.classList.replace('btn-outline-primary', 'btn-primary'); 
            loadAllFeedback(1); 
        } else {
            recentList.style.display = 'block';
            fullList.style.display = 'none';
            btn.innerText = 'View All';
            btn.classList.replace('btn-primary', 'btn-outline-primary');
        }
    }

    function loadAllFeedback(page) {
        $('#ajaxFeedbackContent').html('<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>');
        
        $.ajax({
            url: 'get_all_feedback.php', 
            type: 'POST',
            data: { page: page },
            success: function(res) {
                $('#ajaxFeedbackContent').html(res);
            },
            error: function() {
                $('#ajaxFeedbackContent').html('<p class="text-danger">Error loading data.</p>');
            }
        });
    }

    function openFeedbackModalFromAjax(name, email, date, message) {
        document.getElementById('modalName').innerText = name;
        document.getElementById('modalEmail').innerText = email;
        document.getElementById('modalDate').innerText = date;
        document.getElementById('modalMessage').innerText = message;
        new bootstrap.Modal(document.getElementById('feedbackModal')).show();
    }
</script>
<?php include('footer.php'); ?>