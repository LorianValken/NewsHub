<!-- @import jquery & sweet alert  -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();

//Connection to DB
function connection_db()
{
    $con = new mysqli('','','','');
    return $con;
}

//Move Upload File3
function upload_file($file_name)
{
    $name = date('YmdHis') . '-' . $_FILES[$file_name]['name'];
    $path = '../admin/assets/image/' . $name;
    $tmp_name = $_FILES[$file_name]['tmp_name'];
    move_uploaded_file($tmp_name, $path);
    return $name;
}

//Register Account
function register_account()
{
    if (isset($_POST['btn_register'])) {

        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $created_at = date('Y-m-d');
        $profile = upload_file('profile');

        $con = connection_db();

        // Check if user already exists
        $sql_check = "SELECT * FROM `tbl_user` WHERE `name` = ? OR `email` = ?";
        $stmt_check = $con->prepare($sql_check);
        $stmt_check->bind_param("ss", $name, $email);
        $stmt_check->execute();
        $rs_check = $stmt_check->get_result();

        if ($rs_check->num_rows > 0) {
            echo '
                <script>    
                    $(document).ready(function(){
                        swal({
                            title: "Oppp Erorr!",
                            text: "Username or Email already exists.",
                            icon: "warning",
                            button: "Okay",
                        });
                    });
                </script>
            ';
            return;
        }

        $sql = " INSERT INTO `tbl_user`(`name`, `email`, `password`, `profile`, `created_at`) 
                    VALUES (?, ?, ?, ?, ?) ";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssss", $name, $email, $password, $profile, $created_at);
        $rs = $stmt->execute();

        if ($rs == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Your account has been created successfully.",
                                icon: "success",
                                button: "Okay",
                            }).then(function() {
                                window.location.href = "login.php";
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong, please try again.",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

//Login Account
function login_account()
{
    if (isset($_POST['btn_login'])) {

        $name_email = $_POST['name_email'];
        $password = $_POST['password'];

        $con = connection_db();
        $sql = " SELECT * FROM `tbl_user` WHERE (`name` = ? OR `email` = ?) ";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ss", $name_email, $name_email);
        $stmt->execute();
        $rs = $stmt->get_result();
        $row = mysqli_fetch_assoc($rs);

        if ($row && password_verify($password, $row['password'])) {
            $user_id = $row['id'];
            $_SESSION['id'] = $user_id;
            header('Location: index.php');
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Incorrect username/email or password",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

//Get User Profile
function get_user_profile($user_id)
{
    if (!$user_id) return; // return early if no user_id

    $con = connection_db();
    $sql = "SELECT * FROM tbl_user WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $rs = $stmt->get_result();
    $row = mysqli_fetch_assoc($rs);

    if (!$row) return; // return early if user not found

    echo '
        <img src="assets/image/' . $row['profile'] . '" style="width:80px; height:80px; object-fit: cover; border-radius: 50%; margin-bottom: 10px;" >
        <h6 class="mt-2">Admin. ' . $row['name'] . '</h6>
    ';
}


//Logout Account
function logout_account()
{
    if (isset($_POST['accept'])) {
        unset($_SESSION['id']);
        header('Location: login.php');
    }
    if (isset($_POST['reject'])) {
        header('Location: index.php');
    }
}
// logout_account();

//Add website logo
function add_website_logo()
{
    if (isset($_POST['add_logo'])) {

        $type = $_POST['type'];

        if (!empty($_FILES['thumbnail']['name'])) {
            $thumbnail = upload_file('thumbnail');
        } else {
            $thumbnail = '';
        }

        $con = connection_db();
        $sql = " INSERT INTO `tbl_website_logo`(`thumbnail`, `type`) VALUES (?, ?) ";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ss", $thumbnail, $type);
        $rs = $stmt->execute();

        if ($rs == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Post Inserted",
                                icon: "success",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

//View website logo
function view_website_logo()
{

    $sql = " SELECT * FROM `tbl_website_logo` ORDER BY id DESC ";
    $rs = connection_db()->query($sql);
    while ($row = mysqli_fetch_assoc($rs)) {
        echo '
            <tr>
                <td data-label="Thumbnail"><img src="assets/image/' . $row['thumbnail'] . '" style="width: 100px; height: 60px; object-fit: contain; border-radius: 4px;"/></td>
                <td data-label="Type">' . $row['type'] . '</td>
                <td data-label="Actions" class="text-end pe-4">
                    <a href="website-logo-update-post.php?id=' . $row['id'] . '" class="btn btn-primary btn-sm">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <button type="button" onclick="removePost(' . $row['id'] . ')" class="btn btn-danger btn-sm">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
            ';
    }
}

//Remove website logo
function remove_website_logo()
{
    if (isset($_POST['remove_website_logo'])) {

        $post_id = $_POST['remove_id'];
        $con = connection_db();
        $sql = " DELETE FROM `tbl_website_logo` WHERE id = ? ";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $post_id);
        $rs = $stmt->execute();

        if ($rs == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Post Removed",
                                icon: "success",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

// Update website logo
function update_website_logo()
{
    if (isset($_POST['update_logo'])) {

        $id = $_POST['id'];
        $type = $_POST['type'];

        if (!empty($_FILES['website_logo']['name'])) {
            $thumbnail = upload_file('website_logo');
        } else {
            $thumbnail = $_POST['old_thumbnail'] ?? '';
        }

        $con = connection_db();
        $sql = " UPDATE `tbl_website_logo` SET `thumbnail`=?,`type`=? WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ssi", $thumbnail, $type, $id);
        $rs = $stmt->execute();

        if ($rs == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Post Updated",
                                icon: "success",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

function add_news()
{
    if (isset($_POST['btn_add_news'])) {

        if (!isset($_SESSION['id'])) {
            header("Location: login.php");
            exit();
        }

        $title       = $_POST['title'];
        $news_type   = $_POST['news_type'];
        $category    = $_POST['category'];
        $description = $_POST['description'];
        $created_at  = date('Y-m-d');
        $created_by  = $_SESSION['id'];

        if (!empty($_FILES['thumbnail']['name'])) {
            $thumbnail = upload_file('thumbnail');
        } else {
            echo '
            <script>
                $(document).ready(function(){
                    swal({
                        title: "Error!",
                        text: "Please upload a thumbnail image.",
                        icon: "error",
                        button: "Okay",
                    });
                });
            </script>';
            return;
        }

        $con = connection_db();

        $sql = "INSERT INTO tbl_news
                (title, thumbnail, news_type, category, description, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $con->prepare($sql);
        $stmt->bind_param(
            "sssssis",
            $title,
            $thumbnail,
            $news_type,
            $category,
            $description,
            $created_by,
            $created_at
        );

        if ($stmt->execute()) {
            echo '
            <script>
                swal({
                    title: "Success",
                    text: "Post Inserted",
                    icon: "success",
                }).then(function(){
                    window.location.href = "news-view-post.php";
                });
            </script>';
        } else {
            echo "SQL Error: " . $con->error;
        }
    }
}


//View List News
function view_list_news($offset = 0, $limit = 10)
{
    $con = connection_db();
    $sql = " SELECT news.* ,user.name FROM tbl_news news INNER JOIN tbl_user user ON news.created_by = user.id ORDER BY news.id DESC LIMIT ?, ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ii", $offset, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = mysqli_fetch_assoc($result)) {
        $title = $row['title'];
        $display_title = (strlen($title) > 25) ? substr($title, 0, 26) . '...' : $title;
        echo '
            <tr>
                <td data-label="Title" title="' . $row['title'] . '">' . $display_title . '</td>
                <td data-label="News Type">' . $row['news_type'] . '</td>
                <td data-label="Category">' . $row['category'] . '</td>
                <td data-label="Thumbnail"><img src="assets/image/' . $row['thumbnail'] . '" style="width: 100px; height: 60px; object-fit: cover; border-radius: 4px;" onerror="this.src=\'https://placehold.co/100x60?text=No+Image\'"></td>
                <td data-label="Views">' . $row['viewer'] . '</td>
                <td data-label="Created By">' . $row['name'] . '</td>
                <td data-label="Publish Date">' . $row['created_at'] . '</td>
                <td data-label="Actions" class="text-end" style="white-space: nowrap;">
                    <a href="news-update-post.php?id=' . $row['id'] . '" class="btn btn-primary btn-sm">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <button type="button" remove-id="' . $row['id'] . '" class="btn btn-danger btn-sm btn-remove" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
            ';
    }
}

//Update News
function update_news()
{
    if (isset($_POST['btn_update_news'])) {

        $id = $_POST['id'];
        $old_thumbnail = $_POST['old_thumbnail'];
        $title = $_POST['title'];
        $news_type = $_POST['news_type'];
        $category = $_POST['category'];
        $description = $_POST['description'];
        if (!empty($_FILES['thumbnail']['name'])) {
            $thumbnail = upload_file('thumbnail');
        } else {
            $thumbnail = $old_thumbnail;
        }

        $con = connection_db();
        $sql = "UPDATE `tbl_news` SET `title`=?,`thumbnail`=?,`news_type`=?,`category`=?,`description`=? WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssi", $title, $thumbnail, $news_type, $category, $description, $id);
        $result = $stmt->execute();

        if ($result == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Post Inserted",
                                icon: "success",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }

    if (isset($_POST['btn_view_news'])) {
        header('Location: news-view-post.php');
    }
}

function get_total_records($table_name)
{
    $con = connection_db();
    $sql = "SELECT COUNT(*) as total FROM `$table_name`";
    $rs = $con->query($sql);
    $row = mysqli_fetch_assoc($rs);
    return $row['total'];
}

//Remove News
function remove_news()
{
    if (isset($_POST['btn_remove_news'])) {
        $id = $_POST['remove_id'];
        $con = connection_db();
        $sql = " DELETE FROM `tbl_news` WHERE id = ? ";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();

        if ($result == true) {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Success",
                                text: "Post Removed",
                                icon: "success",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        } else {
            echo '
                    <script>    
                        $(document).ready(function(){
                            swal({
                                title: "Oppp Erorr!",
                                text: "Something went wrong",
                                icon: "warning",
                                button: "Okay",
                            });
                        });
                    </script>
                ';
        }
    }
}

function get_all_feedback($offset = 0, $limit = 10)
{
    $con = connection_db();
    $sql = "SELECT * FROM `tbl_feedback` ORDER BY id DESC LIMIT ?, ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ii", $offset, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = mysqli_fetch_assoc($result)) {
        $message = $row['message'];
        $short_message = strlen($message) > 100 ? substr($message, 0, 100) . '...' : $message;
        $full_message_id = 'full-message-' . $row['id'];

        echo '
            <tr>
                <td data-label="Name">' . htmlspecialchars($row['name']) . '</td>
                <td data-label="Email">' . htmlspecialchars($row['email']) . '</td>
                <td data-label="Phone">' . htmlspecialchars($row['phone']) . '</td>
                <td data-label="Address">' . htmlspecialchars($row['address']) . '</td>
                <td data-label="Feedback" class="w-100">
                    ' . htmlspecialchars($short_message) . '
                    ' . (strlen($message) > 100 ? '<a href="javascript:void(0);" onclick="document.getElementById(\'' . $full_message_id . '\').style.display=\'block\'; this.style.display=\'none\';">Read More</a>' : '') . '
                    <div id="' . $full_message_id . '" style="display:none;">
                        ' . htmlspecialchars($message) . '
                        <a href="javascript:void(0);" onclick="document.getElementById(\'' . $full_message_id . '\').style.display=\'none\'; document.querySelector(\'a[onclick*=' . $full_message_id . ']\').style.display=\'inline\';">Read Less</a>
                    </div>
                </td>
                <td data-label="Date">' . $row['created_at'] . '</td>
            </tr>
            ';
    }
}
