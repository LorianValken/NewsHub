<?php
require_once('function.php');
logout_account();
include('sidebar.php');
?>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    /* Content Area Styles */
    .content-right {
        font-family: 'Inter', sans-serif;
        background-color: #f8fafc;
        min-height: 100vh;
        padding: 20px;
        display: flex;
        align-items: center; /* Vertically Center */
        justify-content: center; /* Horizontally Center */
    }

    /* Centered Logout Card */
    .logout-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
        border: 1px solid #e2e8f0;
        padding: 2.5rem;
        width: 100%;
        max-width: 420px; /* Fixed width for desktop */
        text-align: center;
        transition: transform 0.3s ease;
    }

    /* Icon Styling */
    .icon-wrapper {
        width: 80px;
        height: 80px;
        background-color: #fee2e2; /* Light Red */
        color: #ef4444; /* Red */
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem auto;
    }

    .icon-wrapper i {
        font-size: 2rem;
    }

    /* Typography */
    .logout-title {
        font-size: 1.5rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.5rem;
    }

    .logout-desc {
        color: #64748b;
        font-size: 0.95rem;
        margin-bottom: 2rem;
    }

    /* Buttons */
    .btn-group-action {
        display: flex;
        justify-content: center;
        gap: 15px;
    }

    .btn-action {
        padding: 10px 30px; /* Short/Compact size */
        border-radius: 50px;
        font-weight: 600;
        font-size: 0.95rem;
        border: none;
        cursor: pointer;
        transition: all 0.2s;
        min-width: 100px;
    }

    .btn-yes {
        background-color: #ef4444;
        color: white;
        box-shadow: 0 4px 6px -1px rgba(239, 68, 68, 0.2);
    }
    .btn-yes:hover {
        background-color: #dc2626;
        transform: translateY(-2px);
    }

    .btn-no {
        background-color: #f1f5f9;
        color: #475569;
    }
    .btn-no:hover {
        background-color: #e2e8f0;
        color: #1e293b;
    }

    /* Mobile Responsive Tweaks */
    @media (max-width: 576px) {
        .content-right {
            align-items: flex-start; /* Align top on mobile */
            padding-top: 80px;
        }
        .logout-card {
            padding: 2rem;
        }
        .btn-group-action {
            flex-direction: column-reverse; /* Stack buttons on mobile */
            gap: 10px;
        }
        .btn-action {
            width: 100%; /* Full width on mobile */
            padding: 12px;
        }
    }
</style>

<div class="col-12 col-lg-10">
    <div class="content-right">
        
        <div class="logout-card">
            
            <div class="icon-wrapper">
                <i class="fas fa-power-off"></i>
            </div>
            
            <h3 class="logout-title">Sign Out</h3>
            <p class="logout-desc">Are you sure you want to end your session?</p>
            
            <form method="post" enctype="multipart/form-data">
                <div class="btn-group-action">
                    <button type="submit" class="btn-action btn-no" name="reject">
                        Cancel
                    </button>

                    <button type="submit" class="btn-action btn-yes" name="accept">
                        Log Out
                    </button>
                </div>
            </form>

        </div>

    </div>
</div>

</div>
</div>
</main>
</body>
</html>