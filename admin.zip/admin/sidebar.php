<?php
   if (session_status() === PHP_SESSION_NONE) session_start();
   require_once('function.php');
   $user_id = $_SESSION['id'] ?? null;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/style/bootstrap.css">
    <script src="https://cdn.tiny.cloud/1/ohspuj1qmgare44cyntb3rxk40gfloa9qz2qenjwp3i2gdcp/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

    <style>
        :root {
            --sidebar-bg: #101838;
            --sidebar-width: 260px; /* Fixed width for calculation */
            --text-color: #aeb7c6;
            --text-hover: #ffffff;
            --accent-color: #3b82f6;
            --card-bg: #ffffff;
            --body-bg: #f4f6f9;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--body-bg);
            margin: 0;
            padding: 0;
        }

        /* --- Sidebar Styling --- */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--sidebar-bg);
            color: #fff;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            z-index: 1001;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            border-right: 1px solid rgba(255,255,255,0.05);
        }
        .sidebar::-webkit-scrollbar { display: none; }

        .sidebar-header {
            padding: 20px;
            text-align: center;
        }
        .sidebar-header img { max-width: 140px; height: auto; }
        
        .user-profile-section img {
            border: 3px solid var(--accent-color);
            padding: 3px;
        }

        .user-profile-section { padding: 0 15px 20px 15px; }

        .sidebar-menu { list-style: none; padding: 0 15px 50px 15px; margin: 0; }
        .sidebar-menu li { margin-bottom: 8px; }
        .sidebar-menu a {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 15px; color: var(--text-color);
            text-decoration: none; font-size: 0.95rem;
            border-radius: 10px; transition: all 0.2s ease;
        }
        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.08); color: var(--text-hover);
        }
        .sidebar-menu a span { flex-grow: 1; margin-left: 10px; }
        .child-menu {
            list-style: none; padding-left: 0; background: rgba(0,0,0,0.15);
            border-radius: 10px; margin-top: 5px; display: none;
        }
        .child-menu li a { padding-left: 48px; font-size: 0.9rem; color: #94a3b8; }
        .child-menu li a:hover { color: #fff; background: transparent; }

        /* --- THE FIX: Main Content Area Calculation --- */
        .main-content {
            /* Instead of col-lg-10, we force a left margin equal to the sidebar width.
               This ensures content never hides behind the sidebar.
            */
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
            min-height: 100vh;
            padding: 30px;
            transition: all 0.3s ease;
            position: relative;
        }

        /* --- Mobile Header --- */
        .mobile-header {
            display: none;
            background: #fff;
            padding: 0 20px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0; left: 0; right: 0;
            z-index: 1000;
            height: 60px;
        }
        .menu-toggle {
            background: none; border: none; font-size: 1.8rem;
            cursor: pointer; color: var(--sidebar-bg); padding: 0;
        }

        /* --- Responsive Logic --- */
        @media (max-width: 991px) {
            .mobile-header { display: flex; }

            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
                box-shadow: 5px 0 25px rgba(0,0,0,0.3);
            }

            /* On mobile, remove the margin so content is full width */
            .main-content {
                margin-left: 0 !important;
                width: 100% !important;
                padding-top: 80px !important; /* Push down below mobile header */
            }
            
            .overlay {
                display: none; position: fixed; top: 0; left: 0;
                width: 100vw; height: 100vh; background: rgba(0,0,0,0.6);
                z-index: 1000; backdrop-filter: blur(2px);
            }
            .overlay.active { display: block; }
        }
    </style>
</head>
<body>

    <div class="mobile-header">
        <div class="logo-area">
            <img src="assets/icon/logo-admin.png" alt="Logo" style="height: 35px; width: auto;">
        </div>
        <button class="menu-toggle" id="menuToggle">
            <i class="bi bi-list"></i>
        </button>
    </div>

    <div class="overlay" id="sidebarOverlay"></div>

    <nav class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="assets/icon/logo-admin.png" alt="Admin Logo">
        </div>
        <div class="user-profile-section">
            <?php echo get_user_profile($user_id); ?>
        </div>
        <ul class="sidebar-menu">
            
            <li><a href="index.php"><i class="bi bi-speedometer2"></i><span>Dashboard</span></a></li>
            <li><a href="../index.php"><i class="bi bi-house"></i><span>Home Page</span></a></li>
            
            <li>
                <a href="javascript:void(0)" class="menu-dropdown-toggle">
                    <i class="bi bi-image"></i><span>Website Logo</span>
                    <i class="bi bi-chevron-right arrow-icon"></i>
                </a>
                <ul class="child-menu">
                    <li><a href="website-logo-view-post.php">View Post</a></li>
                    <li><a href="website-logo-add-post.php">Add New</a></li>
                </ul>
            </li>

            <li>
                <a href="javascript:void(0)" class="menu-dropdown-toggle">
                    <i class="bi bi-newspaper"></i><span>News Post</span>
                    <i class="bi bi-chevron-right arrow-icon"></i>
                </a>
                <ul class="child-menu">
                    <li><a href="news-view-post.php">View Post</a></li>
                    <li><a href="news-add-post.php">Add New</a></li>
                </ul>
            </li>
            <li>
                <a href="logout.php" style="color: #ff6b6b; margin-top: 20px;">
                    <i class="bi bi-box-arrow-right"></i><span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="assets/js/bootstrap.js"></script>

<script>
        $(document).ready(function() {
            $('#menuToggle, #sidebarOverlay').click(function() {
                $('#sidebar').toggleClass('active');
                $('#sidebarOverlay').toggleClass('active');
            });

            $('.menu-dropdown-toggle').click(function() {
                $(this).next('.child-menu').slideToggle(200);
                var expanded = $(this).attr('aria-expanded') === 'true';
                $(this).attr('aria-expanded', !expanded);
            });
        });
    </script>
    
    <div class="main-content container-fluid p-4">
