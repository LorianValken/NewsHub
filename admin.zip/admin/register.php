<?php 
    include('function.php');
    register_account();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | News Portal</title>
    <link rel="stylesheet" href="assets/style/register.css">
</head>

<body>

    <div class="register-wrapper">
        <div class="register-card">

            <!-- Brand / Logo -->
            <div class="brand">
                <h1>NEWS<span>HUB</span></h1>
                <p>Create your account to join our newsroom</p>
            </div>

            <!-- Register Form -->
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="name" placeholder="Enter username" required>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="Enter email" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Create password" required>
                </div>

                <div class="form-group">
                    <label>Profile Photo</label>

                    <div class="upload-box" id="upload-box">
                        <span id="upload-text">Click to upload</span>
                        <img id="image-preview" alt="Preview" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%; display: none;">
                        <input type="file" name="profile" id="profile-input" accept="image/*">
                    </div>
                </div>


                <button type="submit" name="btn_register" class="btn-register">
                    Sign Up
                </button>

                <div class="footer-link">
                    Already have an account?
                    <a href="login.php">Login</a>
                </div>
            </form>

        </div>
    </div>

    <script>
        document.getElementById('profile-input').onchange = function(evt) {
            const [file] = this.files;
            if (file) {
                const preview = document.getElementById('image-preview');
                const uploadText = document.getElementById('upload-text');
                preview.src = URL.createObjectURL(file);
                preview.style.display = 'block';
                uploadText.style.display = 'none';
                preview.onload = function() {
                    URL.revokeObjectURL(preview.src);
                }
            }
        }
    </script>

</body>

</html>