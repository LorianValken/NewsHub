<?php 
    include('function.php');
    login_account();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="assets/style/login.css">
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">

        <!-- Brand -->
        <div class="brand">
            <h1>NEWS<span>HUB</span></h1>
            <p>Sign in to your newsroom account</p>
        </div>

        <!-- Login Form -->
        <form method="post">
            <div class="form-group">
                <label>Name or Email</label>
                <input type="text" name="name_email" placeholder="Enter name or email" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter password" required>
            </div>

            <button type="submit" name="btn_login" class="btn-login">
                Login
            </button>

            <div class="footer-link">
                Don’t have an account?
                <a href="register.php">Create one</a>
            </div>
        </form>

    </div>
</div>

</body>
</html>
