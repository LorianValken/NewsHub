<?php
session_start();
include_once('function.php');
add_news();
include_once('sidebar.php');
?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<div class="col-12 col-lg-10 bg-light"> 
    <div class="content-right p-3 p-md-4"> 
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
            <div>
                <h3 class="fw-bold text-dark m-0">Create News</h3>
                <p class="text-muted small m-0">Fill in the details below to publish a new article.</p>
            </div>
            <a href="news-view-post.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3 align-self-start align-self-md-center">
                <i class="bi bi-arrow-left"></i> Back to List
            </a>
        </div>

        <style>
            .form-label {
                font-weight: 600;
                color: #495057;
                font-size: 0.9rem;
                margin-bottom: 0.5rem;
            }
            .form-control, .form-select {
                border-radius: 8px;
                border: 1px solid #ced4da;
                padding: 10px 15px;
                font-size: 0.95rem;
            }
            .form-control:focus, .form-select:focus {
                box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.15);
                border-color: #86b7fe;
            }
            
            /* Modern File Upload Styling */
            .upload-container {
                position: relative;
                width: 100%;
                height: 250px;
                border: 2px dashed #dee2e6;
                border-radius: 12px;
                background-color: #f8f9fa;
                transition: all 0.3s ease;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                cursor: pointer;
                z-index: 100;
            }
            
            /* Mobile adjustment for upload box height */
            @media (max-width: 576px) {
                .upload-container {
                    height: 200px;
                }
            }
            
            .upload-container:hover {
                border-color: #0d6efd;
                background-color: #f1f8ff;
            }

            .upload-container input[type="file"] {
                position: absolute;
                width: 100%;
                height: 100%;
                opacity: 0;
                cursor: pointer;
                z-index: 10;
            }

            .upload-icon {
                font-size: 3rem;
                color: #adb5bd;
                margin-bottom: 10px;
                transition: color 0.3s;
            }

            .upload-container:hover .upload-icon {
                color: #0d6efd;
            }

            .preview-image {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                object-fit: contain;
                z-index: 5;
                display: none; 
            }
            
            .remove-preview {
                position: absolute;
                top: 10px;
                right: 10px;
                z-index: 20;
                background: rgba(255, 255, 255, 0.9);
                border-radius: 50%;
                width: 30px;
                height: 30px;
                display: none;
                align-items: center;
                justify-content: center;
                color: #dc3545;
                cursor: pointer;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                transition: all 0.2s;
            }
            .remove-preview:hover {
                background: #dc3545;
                color: white;
            }
        </style>

        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-3 p-md-4"> 
                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label">News Title</label>
                                <input type="text" class="form-control" name="title" placeholder="Enter an engaging headline..." required>
                            </div>

                            <div class="row mb-4">
                                <div class="col-12 col-md-6 mb-3 mb-md-0"> <label class="form-label">News Type</label>
                                    <select class="form-select" name="news_type" required>
                                        <option value="" disabled selected>Select Type</option>
                                        <option value="sport">Sport</option>
                                        <option value="social">Social</option>
                                        <option value="entertainment">Entertainment</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category" required>
                                        <option value="" disabled selected>Select Category</option>
                                        <option value="national">National</option>
                                        <option value="international">International</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label d-flex justify-content-between">
                                    <span>Thumbnail Image</span>
                                    <span class="text-muted fw-normal small">Rec: 730 x 415px</span>
                                </label>
                                <div class="upload-container" id="uploadZone">
                                    <input type="file" id="thumbnail" name="thumbnail" accept="image/*" required>
                                    
                                    <div id="placeholderContent">
                                        <i class="bi bi-cloud-arrow-up upload-icon"></i>
                                        <h6 class="mb-1 text-dark">Click to upload or drag & drop</h6>
                                        <span class="text-muted small">SVG, PNG, JPG or GIF</span>
                                    </div>

                                    <img src="" alt="Preview" class="preview-image" id="filePreview">
                                    
                                    <div class="remove-preview" id="removeBtn" title="Remove Image">
                                        <i class="bi bi-x"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Content Description</label>
                                <textarea class="form-control" name="description" rows="6" placeholder="Write your article content here..." required></textarea>
                            </div>

                            <hr class="my-4 text-muted opacity-25">

                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="news-view-post.php" class="btn btn-light border px-4 order-2 order-md-1">
                                    <i class="bi bi-eye me-1"></i> View All
                                </a>
                                <button type="submit" class="btn btn-primary px-5 fw-bold shadow-sm order-1 order-md-2" name="btn_add_news">
                                    <i class="bi bi-send me-1"></i> Publish News
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    const input = document.getElementById('thumbnail');
    const preview = document.getElementById('filePreview');
    const placeholder = document.getElementById('placeholderContent');
    const removeBtn = document.getElementById('removeBtn');
    const uploadZone = document.getElementById('uploadZone');

    input.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                placeholder.style.display = 'none';
                removeBtn.style.display = 'flex';
                uploadZone.style.borderStyle = 'solid';
            }
            reader.readAsDataURL(file);
        }
    });

    removeBtn.addEventListener('click', function(e) {
        e.preventDefault(); 
        input.value = ''; 
        preview.src = '';
        preview.style.display = 'none';
        placeholder.style.display = 'block';
        removeBtn.style.display = 'none';
        uploadZone.style.borderStyle = 'dashed';
    });
</script>

<?php 
    include('footer.php');
?>