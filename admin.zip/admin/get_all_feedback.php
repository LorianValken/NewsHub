<?php
include('function.php');

$limit = 5;
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$offset = ($page - 1) * $limit;

$total_records = get_total_records('tbl_feedback');
$total_pages = ceil($total_records / $limit);

?>
<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead class="table-light"><tr><th>User</th><th>Email</th><th>Phone</th><th>Address</th><th>Message</th><th>Date</th></tr></thead>
        <tbody>
            <?php get_all_feedback($offset, $limit); ?>
        </tbody>
    </table>
</div>

<nav class="d-flex justify-content-center mt-3 p-3">
    <ul class="pagination pagination-sm">
        <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
            <a class="page-link" href="javascript:void(0)" onclick="loadAllFeedback(<?php echo $page-1; ?>)">Prev</a>
        </li>
        <?php for($i=1; $i<=$total_pages; $i++): ?>
        <li class="page-item <?php if($page == $i) echo 'active'; ?>">
            <a class="page-link" href="javascript:void(0)" onclick="loadAllFeedback(<?php echo $i; ?>)"><?php echo $i; ?></a>
        </li>
        <?php endfor; ?>
        <li class="page-item <?php if($page >= $total_pages) echo 'disabled'; ?>">
            <a class="page-link" href="javascript:void(0)" onclick="loadAllFeedback(<?php echo $page+1; ?>)">Next</a>
        </li>
    </ul>
</nav>