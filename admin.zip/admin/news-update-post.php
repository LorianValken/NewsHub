<?php 
    include('sidebar.php');
    update_news();

    // Fetch data
    $id  = $_GET['id'];
    $sql = "SELECT * FROM `tbl_news` WHERE id = $id";
    $rs  = connection_db()->query($sql);
    $row = mysqli_fetch_assoc($rs);

    // DEFINE IMAGE PATH (Ensure this folder exists and matches your storage logic)
    $image_path = "assets/image/" . $row['thumbnail']; 
?>

<div class="col-12 col-lg-10 bg-light transition-all"> 
    
    <div class="content-right p-3 p-md-4">
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
            <div>
                <h3 class="fw-bold text-dark m-0">Update News</h3>
            </div>
            
            <a href="news-view-post.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>

        <style>
            .form-label { font-weight: 600; color: #495057; font-size: 0.9rem; }
            .form-control, .form-select { border-radius: 8px; padding: 10px 15px; border: 1px solid #ced4da; }
            
            /* UPLOAD ZONE STYLING */
            .upload-container {
                position: relative;
                width: 100%;
                height: 200px; 
                border: 2px dashed #dee2e6;
                border-radius: 12px;
                background-color: #f8f9fa;
                overflow: hidden;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            }

            @media (min-width: 768px) {
                .upload-container { height: 300px; }
            }

            .upload-container input[type="file"] {
                position: absolute; 
                width: 100%; 
                height: 100%; 
                opacity: 0; 
                cursor: pointer; 
                z-index: 20; 
            }

            .preview-image {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                object-fit: contain; 
                z-index: 10;
                background-color: #fff;
            }
            
            .upload-placeholder {
                z-index: 5;
                color: #adb5bd;
                text-align: center;
            }
        </style>

        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-3 p-md-4"> 
                        <form method="post" enctype="multipart/form-data">
                            
                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                            <input type="hidden" name="old_thumbnail" value="<?php echo $row['thumbnail'] ?>">

                            <div class="mb-3">
                                <label class="form-label">Title</label>
                                <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($row['title']); ?>">
                            </div>

                            <div class="row mb-3">
                                <div class="col-12 col-md-6 mb-3 mb-md-0">
                                    <label class="form-label">News Type</label>
                                    <select class="form-select" name="news_type">
                                        <option value="sport" <?php if($row['news_type'] == 'sport') echo 'selected'; ?>>Sport</option>
                                        <option value="social" <?php if($row['news_type'] == 'social') echo 'selected'; ?>>Social</option>
                                        <option value="entertainment" <?php if($row['news_type'] == 'entertainment') echo 'selected'; ?>>Entertainment</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category">
                                        <option value="national" <?php if($row['category'] == 'national') echo 'selected'; ?>>National</option>
                                        <option value="international" <?php if($row['category'] == 'international') echo 'selected'; ?>>International</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Thumbnail Preview</label>
                                <div class="upload-container">
                                    <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
                                    
                                    <img src="<?php echo $image_path; ?>" 
                                         id="filePreview" 
                                         class="preview-image" 
                                         onerror="this.style.display='none'">

                                    <div class="upload-placeholder">
                                        <i class="bi bi-cloud-upload fs-2"></i>
                                        <p class="m-0">Click to upload new image</p>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="5"><?php echo htmlspecialchars($row['description']); ?></textarea>
                            </div>

                            <div class="d-flex justify-content-end gap-2">
                                <button type="submit" class="btn btn-primary px-4" name="btn_update_news">Update</button>
                                <a href="news-view-post.php" class="btn btn-success px-4">View List</a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const input = document.getElementById('thumbnail');
    const preview = document.getElementById('filePreview');

    input.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                // Replace old image with the newly selected one
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });
</script>